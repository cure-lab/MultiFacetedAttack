# MFA Responses

This dataset contains original model-response logs from
Multi-Faceted Attack on Vision-Language Models.
It supports safety evaluation of previously generated responses.

## Dataset Structure

All records are stored in one file: `mfa_responses.json`.
The top-level JSON object contains 17 groups.
Each group corresponds to one original JSONL file.
Group names are the original filenames without the `.jsonl` extension.
Each group contains a list of original sample records.

## Sample Fields

- `prompt_id`: original sample identifier.
- `prompt`: input prompt.
- `responses`: a list of response objects.
  - `round`: generation round.
  - `response`: model response text.

Original sample fields, ordering, and text are preserved.
Safety labels are not included.

## Load Locally

    import json

    with open("mfa_responses.json", encoding="utf-8") as f:
        dataset = json.load(f)

    print(list(dataset.keys()))
    samples = dataset["MiMo-VL-7B_multifacet"]
    print(samples[0]["responses"][0]["response"])

## Download from Hugging Face

Install `huggingface_hub`, then run:

    import json
    from huggingface_hub import hf_hub_download

    path = hf_hub_download(
        repo_id="USERNAME/MFA-Responses",
        filename="mfa_responses.json",
        repo_type="dataset",
    )
    with open(path, encoding="utf-8") as f:
        dataset = json.load(f)

    samples = dataset["MiMo-VL-7B_multifacet"]



## Safety Evaluation

Select a group and pass its recorded responses to a safety evaluator.
Running the original target model is not required.

    for sample in samples:
        answer = sample["responses"][0]["response"]
        # Pass answer to your safety evaluator.

This example selects the first response from each sample.
Report the evaluator, preprocessing, and aggregation rules.
Automated harmfulness judgments differ from human-verified attack success.
